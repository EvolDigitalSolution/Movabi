import {calculateCalendarAge,CanonicalDriverProfile,mapDriverProfile,parseDriverDateOfBirth} from '../models/driver-profile.model';
import { readPassengerLicence } from '../models/driver-passenger-licence.model';

export type CanonicalDriverService = 'ride' | 'delivery' | 'errand' | 'van-moving';
export type DriverOperatingVehicle = 'bicycle' | 'e_bike' | 'motorcycle' | 'car' | 'small_van' | 'large_van' | null;
export type RequirementState = 'completed' | 'missing' | 'invalid' | 'under_age' | 'under_review' | 'approved' | 'rejected' | 'not_applicable' | 'expired';
export interface ResolvedDriverRequirement {
  code: string; label: string; category: 'basic' | 'services' | 'vehicle' | 'documents' | 'agreement' | 'licensing';
  status: RequirementState; required: boolean; completed: boolean; blockingForSubmission: boolean; blockingForOnline: boolean;
  needsAdminReview: boolean; reason: string; services: CanonicalDriverService[];
  expiryDate?: string | null; expiringSoon?: boolean;
}
export interface DriverAdminRequest { id: string; requirementCode: string; requestType?:string|null; item: string; status: 'pending'|'rejected'|'approved'; publicMessage: string; submittedAt: string|null; updatedAt: string|null; resolvedAt: string|null; nextAction: string; }
export interface DriverRequirementResolution {
  selectedServices: CanonicalDriverService[]; vehicleType: DriverOperatingVehicle; automaticRequirements: ResolvedDriverRequirement[];
  adminRequests: DriverAdminRequest[]; warnings: ResolvedDriverRequirement[];
  overallStatus: 'not_started'|'incomplete'|'ready_to_submit'|'under_review'|'action_required'|'approved'|'paused';
  onlineEligibility: { allowed: boolean; reasons: string[] }; age: { eligible: boolean; years: number|null; minimum: number; reason: string|null };
  sectionStatus:DriverSetupSectionStatus; progress:{completed:number;total:number;percentage:number};
}
export type DriverSetupSectionState='not_applicable'|'incomplete'|'complete'|'action_required'|'under_review';
export interface DriverSetupSection {applicable:boolean;status:DriverSetupSectionState;}
export interface DriverSetupSectionStatus {basicDetails:DriverSetupSection;services:DriverSetupSection;operatingMethod:DriverSetupSection;vehicle:DriverSetupSection;documents:DriverSetupSection;serviceLicensing:DriverSetupSection;agreement:DriverSetupSection;review:DriverSetupSection;}
export interface DriverVehicleValidation {id:string;userId:string;type:string;subtype:string|null;make:string|null;model:string|null;colour:string|null;year:number|null;registrationNumber:string|null;capacity:string|null;serviceEligibility:string[];status:string;}
/** Server-verified payment-account state for the driver's configured market. */
export interface DriverPaymentAccountInput {provider:string|null;state:'not_started'|'in_progress'|'action_required'|'reconciliation_required'|'completed'|'unavailable';available:boolean;reason?:string|null;}

export class DriverRequirementService {
  static resolve(input: { profile: any; canonicalProfile?:CanonicalDriverProfile; vehicle?: DriverVehicleValidation|null; authEmailConfirmed: boolean; adminRequests?: DriverAdminRequest[]; countryCode?: string|null; marketCity?: string|null; now?: Date; paymentAccount?: DriverPaymentAccountInput|null }): DriverRequirementResolution {
    const profile=input.profile||{}, onboardingItems=this.onboardingItems(profile.verification_items), vehicle:DriverVehicleValidation=input.vehicle||{id:'',userId:'',type:'',subtype:null,make:null,model:null,colour:null,year:null,registrationNumber:null,capacity:null,serviceEligibility:[],status:'missing'}, now=input.now||new Date();
    const canonicalProfile=input.canonicalProfile||mapDriverProfile({id:String(profile.id||''),...profile},input.authEmailConfirmed);
    const selectedServices=this.services(profile,vehicle,onboardingItems); const vehicleType=this.vehicle(vehicle,profile); const requirements:ResolvedDriverRequirement[]=[];
    const add=(code:string,label:string,category:ResolvedDriverRequirement['category'],ok:boolean,reason:string,services:CanonicalDriverService[]=selectedServices,invalid=false,review=false,expiryDate:string|null=null,expiringSoon=false)=>requirements.push({code,label,category,status:ok?(review?'under_review':'completed'):(invalid?'invalid':'missing'),required:true,completed:ok&&!review,blockingForSubmission:!ok,blockingForOnline:!ok||review,needsAdminReview:review,reason,services,expiryDate,expiringSoon});
    // Document/licence requirement with canonical expiry evaluation. Expiry is
    // date-only (YYYY-MM-DD) and only checked when the document is present and
    // actually applicable to the selected services.
    const addDocument=(code:string,label:string,hasDoc:boolean,expiryValue:unknown,missingReason:string,services:CanonicalDriverService[]=selectedServices)=>{const exp=this.expiryState(expiryValue,now);const expired=hasDoc&&exp.expired;const ok=hasDoc&&!expired;requirements.push({code,label,category:'documents',status:hasDoc?(expired?'expired':'completed'):'missing',required:true,completed:ok,blockingForSubmission:!ok,blockingForOnline:!ok,needsAdminReview:false,reason:expired?`${label} has expired.`:missingReason,services,expiryDate:exp.expiryDate,expiringSoon:hasDoc&&exp.expiringSoon});};
    add('profile.full_name','Legal name','basic',this.has(canonicalProfile.fullName),'Add your full legal name.');
    add('profile.phone','Phone','basic',this.has(canonicalProfile.phone),'Add your contact number.');
    add('profile.address','Residential address','basic',this.has(canonicalProfile.residentialAddress),'Add your current residential address.');
    add('profile.email_verification','Email verified','basic',canonicalProfile.emailConfirmed,'Confirm your sign-in email address.');
    const age=this.age(canonicalProfile.dateOfBirth,now,18);
    requirements.push({code:'profile.date_of_birth',label:'Date of birth',category:'basic',status:age.state,required:true,completed:age.eligible,blockingForSubmission:!age.eligible,blockingForOnline:!age.eligible,needsAdminReview:false,reason:age.reason||'Date of birth confirmed.',services:[]});
    add('service.selection','Selected services','services',selectedServices.length>0,'Select at least one service.');
    add('agreement.driver_terms','Driver agreement','agreement',this.has(profile.accepted_driver_agreement_at),'Review and accept the Driver Agreement.');
    const country=String(input.countryCode||profile.country_code||'').toUpperCase();
    if(country==='GB') add('work.right_to_work','Right to work','documents',this.has(profile.right_to_work_url||profile.right_to_work_share_code),'Provide right-to-work evidence.');

    if(selectedServices.length){
      const subtype=String(vehicle.subtype||'').toLowerCase();
      const motor=vehicleType!==null&&vehicleType!=='bicycle'&&vehicleType!=='e_bike';
      const vehicleBased=motor||selectedServices.includes('ride')||selectedServices.includes('van-moving');
      const isBike=['bicycle','e_bike','motorcycle'].includes(vehicleType||'');
      add('vehicle.operating_method','Operating method','vehicle',vehicleType!==null,'Choose how you will provide the selected services.');
      if(isBike){
        add('vehicle.subtype','Vehicle subtype','vehicle',['pedal_bicycle','e_bike','motorcycle','moped'].includes(subtype),'Select your bike type (pedal bicycle, e-bike, motorcycle or moped).');
      }
      if(vehicleType==='e_bike'){
        add('vehicle.make','Vehicle make','vehicle',this.has(vehicle.make),'Add the vehicle make.'); add('vehicle.model','Vehicle model','vehicle',this.has(vehicle.model),'Add the vehicle model.');
        add('vehicle.colour','Vehicle colour','vehicle',this.has(vehicle.colour),'Add the vehicle colour.'); add('vehicle.year','Vehicle year','vehicle',Number(vehicle.year)>1900,'Add a valid vehicle year.');
        add('document.e_bike_specifications','E-bike specifications','documents',!!onboardingItems['e_bike_specifications'],'Provide e-bike motor power, battery voltage and maximum assisted speed for market classification.');
        const marketClass=String(onboardingItems['e_bike_market_class']||'').toLowerCase();
        if(marketClass==='motor'){
          add('vehicle.registration','Vehicle registration','vehicle',this.has(vehicle.registrationNumber),'Add the registration number.');
          addDocument('document.driving_licence','Driving licence',this.has(profile.driver_license_url||profile.driving_licence_url),profile.driver_license_expiry,'Upload the appropriate driving licence.');
          addDocument('document.insurance','Vehicle insurance',this.has(profile.insurance_url||profile.courier_insurance_url||profile.hire_reward_insurance_url),profile.insurance_expiry,'Insurance covering your vehicle for the services you accept.');
        } else if(marketClass==='bicycle'){
          add('vehicle.bicycle_declaration','Bicycle details','vehicle',this.has(vehicle.type)||onboardingItems['bicycle_declaration']===true,'Add bicycle details or confirm your bicycle declaration.');
          add('vehicle.delivery_equipment','Delivery equipment','vehicle',onboardingItems['delivery_equipment_confirmed']===true,'Confirm suitable delivery equipment.');
          add('document.bike_inspection','Bike inspection','documents',onboardingItems['bike_inspection_approved']===true,'Complete a bike inspection and upload the evidence.');
        } else {
          requirements.push({code:'document.e_bike_classification',label:'E-bike market classification',category:'documents',status:'under_review',required:true,completed:false,blockingForSubmission:true,blockingForOnline:true,needsAdminReview:true,reason:'This e-bike has not been classified for the market yet. An admin review is required.',services:selectedServices});
        }
      } else if(vehicleBased){
        add('vehicle.make','Vehicle make','vehicle',this.has(vehicle.make),'Add the vehicle make.'); add('vehicle.model','Vehicle model','vehicle',this.has(vehicle.model),'Add the vehicle model.');
        add('vehicle.colour','Vehicle colour','vehicle',this.has(vehicle.colour),'Add the vehicle colour.'); add('vehicle.year','Vehicle year','vehicle',Number(vehicle.year)>1900,'Add a valid vehicle year.');
        add('vehicle.registration','Vehicle registration','vehicle',this.has(vehicle.registrationNumber),'Add the registration number.');
        addDocument('document.driving_licence','Driving licence',this.has(profile.driver_license_url||profile.driving_licence_url),profile.driver_license_expiry,'Upload the appropriate driving licence.');
        addDocument('document.insurance','Vehicle insurance',this.has(profile.insurance_url||profile.courier_insurance_url||profile.hire_reward_insurance_url),profile.insurance_expiry,'Insurance covering your vehicle for the services you accept.');
      } else if(vehicleType==='bicycle') {
        add('vehicle.make','Vehicle make','vehicle',this.has(vehicle.make),'Add the vehicle make.'); add('vehicle.model','Vehicle model','vehicle',this.has(vehicle.model),'Add the vehicle model.');
        add('vehicle.colour','Vehicle colour','vehicle',this.has(vehicle.colour),'Add the vehicle colour.'); add('vehicle.year','Vehicle year','vehicle',Number(vehicle.year)>1900,'Add a valid vehicle year.');
        add('vehicle.bicycle_declaration','Bicycle details','vehicle',this.has(vehicle.type)||onboardingItems['bicycle_declaration']===true,'Add bicycle details or confirm your bicycle declaration.');
        add('vehicle.delivery_equipment','Delivery equipment','vehicle',onboardingItems['delivery_equipment_confirmed']===true,'Confirm suitable delivery equipment.');
        add('document.bike_inspection','Bike inspection','documents',onboardingItems['bike_inspection_approved']===true,'Complete a bike inspection and upload the evidence.');
      }
      if(selectedServices.includes('ride')){
        // Canonical passenger-licence evaluation: the licensing requirement is
        // satisfied by the canonical council_name + licence number + badge +
        // expiry (readPassengerLicence), NOT by an ad-hoc vehicle-licence URL.
        const passengerLicence=readPassengerLicence(profile, now);
        const hasAllLicenceFields=!!(passengerLicence.councilName&&passengerLicence.licenceNumber&&passengerLicence.badgeNumber&&passengerLicence.expiryDate);
        const licenceExpired=!passengerLicence.complete&&hasAllLicenceFields;
        const licenceExpiry=this.expiryState(passengerLicence.expiryDate,now);
        const licenceExpiringSoon=passengerLicence.complete&&licenceExpiry.expiringSoon;
        // Name exactly which canonical fields are outstanding so a driver is never
        // left with an unexplained generic "Incomplete".
        const missingLicenceFields=[
          !passengerLicence.councilName?'licensing authority':null,
          !passengerLicence.licenceNumber?'private hire licence number':null,
          !passengerLicence.badgeNumber?'taxi/private hire badge number':null,
          !passengerLicence.expiryDate?'licence expiry date':null
        ].filter((item):item is string=>item!==null);
        const licenceReason=missingLicenceFields.length
          ? `Provide the passenger-service licensing configured for this market. Missing: ${missingLicenceFields.join(', ')}.`
          : 'Provide the passenger-service licensing configured for this market.';
        if(licenceExpired){
          requirements.push({code:'licence.private_hire',label:'Private-hire/council licensing',category:'licensing',status:'expired',required:true,completed:false,blockingForSubmission:true,blockingForOnline:true,needsAdminReview:false,reason:'Private-hire driver licence has expired.',services:['ride'],expiryDate:passengerLicence.expiryDate,expiringSoon:false});
        } else {
          add('licence.private_hire','Private-hire/council licensing','licensing',passengerLicence.complete,licenceReason,['ride'],false,false,passengerLicence.expiryDate,licenceExpiringSoon);
        }
        addDocument('document.private_hire_vehicle_license','Private-hire vehicle licence',this.has(profile.private_hire_vehicle_license_url),profile.vehicle_license_expiry,'Upload your private-hire/taxi vehicle licence.',['ride']);
        add('document.private_hire_insurance','Private-hire insurance','documents',this.has(profile.private_hire_insurance_url),'Insurance covering you to carry passengers for hire or reward.',['ride']);
      }
      if(selectedServices.includes('van-moving')){const gitRequired=country==='GB';addDocument('document.goods_in_transit','Goods-in-transit cover',gitRequired?this.has(profile.goods_in_transit_insurance_url):true,gitRequired?profile.goods_in_transit_insurance_expiry:null,'Upload configured commercial or goods-in-transit cover.',['van-moving']);}
    }
    // Payment-account requirement. GB keeps the existing owner-authenticated
    // Stripe Connect path. Every other market must satisfy the provider that
    // trusted server configuration selected for it (never "non-GB means
    // Flutterwave"); a market with no approved provider blocks onboarding
    // instead of falsely completing it.
    // Completion means the provider destination matches the recorded details.
    // It does NOT prove driver identity, account ownership, KYC or live payout
    // readiness — those remain separate requirements/authorities.
    {
      const payment=input.paymentAccount;
      const expectedProvider=country==='GB'?'stripe':country==='NG'?'flutterwave':null;
      const ready=payment?.state==='completed'&&payment.available===true&&(!expectedProvider||payment.provider===expectedProvider);
      const unavailable=!payment||payment.state==='unavailable';
      const reason=unavailable
        ? 'Payment account setup is not available in your market yet.'
        : payment!.state==='in_progress'
          ? 'Payment account setup is in progress. Refresh before continuing.'
          : payment!.state==='action_required'||payment!.state==='reconciliation_required'
            ? (payment!.reason||'Payment account setup needs reconciliation. Check the status before retrying.')
            : ready
              ? 'Payment account destination verified with the provider record.'
              : 'Set up your payment account to receive earnings from completed jobs.';
      requirements.push({code:'payout.payment_account',label:'Payment account',category:'documents',status:ready?'completed':'missing',required:true,completed:ready,blockingForSubmission:!ready,blockingForOnline:!ready,needsAdminReview:payment?.state==='action_required',reason,services:selectedServices});
    }
    const automaticCodes=new Set(requirements.map(r=>r.code));
    const adminRequests=(input.adminRequests||[]).filter((request,index,array)=>!automaticCodes.has(request.requirementCode)&&array.findIndex(item=>item.requirementCode===request.requirementCode&&item.status!=='approved')===index);
    const required=requirements.filter(r=>r.required); const blockers=required.filter(r=>r.blockingForSubmission);
    const openAdmin=adminRequests.filter(r=>r.status!=='approved'); const review=profile.verification_status==='under_review'||profile.driver_review_status==='under_review'; const actionRequired=profile.verification_status==='action_required'||profile.driver_review_status==='action_required'; const approved=profile.is_verified===true||profile.verification_status==='approved'; const paused=['paused','suspended','blocked'].includes(String(profile.account_status||'').toLowerCase());
    const overallStatus=paused?'paused':actionRequired||openAdmin.length||requirements.some(r=>r.status==='invalid'||r.status==='under_age'||r.status==='rejected'||r.status==='expired')?'action_required':approved?'approved':review?'under_review':!selectedServices.length?'not_started':blockers.length?'incomplete':'ready_to_submit';
    const onlineReasons=[...required.filter(r=>r.blockingForOnline).map(r=>r.reason),...openAdmin.map(r=>r.publicMessage||r.item)];
    for(const service of selectedServices){const approvals=profile.service_approval_statuses||{};if((service==='ride'||service==='van-moving')&&approvals[service]!=='approved')onlineReasons.push(`${service} approval is pending.`);}
    if(!approved)onlineReasons.push('Driver onboarding is not approved.'); if(paused)onlineReasons.push('Driver account is paused or suspended.');
    const warnings:ResolvedDriverRequirement[]=[]; if(country==='GB'&&profile.stripe_connect_status!=='connected')warnings.push({code:'payout.stripe_connect',label:'Stripe payouts',category:'documents',status:'missing',required:false,completed:false,blockingForSubmission:false,blockingForOnline:false,needsAdminReview:false,reason:'Complete Stripe Connect before receiving payouts.',services:[]});
    const section=(rows:ResolvedDriverRequirement[],applicable=true):DriverSetupSection=>{if(!applicable)return{applicable:false,status:'not_applicable'};if(rows.some(row=>row.status==='invalid'||row.status==='under_age'||row.status==='rejected'||row.status==='expired'))return{applicable:true,status:'action_required'};if(rows.some(row=>row.status==='under_review'))return{applicable:true,status:'under_review'};return{applicable:true,status:rows.length>0&&rows.every(row=>row.completed)?'complete':'incomplete'};};
    const byCategory=(category:ResolvedDriverRequirement['category'])=>requirements.filter(row=>row.category===category);
    const vehicleRows=byCategory('vehicle'),operatingRows=vehicleRows.filter(row=>row.code==='vehicle.operating_method'),vehicleDetailRows=vehicleRows.filter(row=>row.code!=='vehicle.operating_method');
    const licensingRows=byCategory('licensing');
    const sectionStatus:DriverSetupSectionStatus={basicDetails:section(byCategory('basic')),services:section(byCategory('services')),operatingMethod:section(operatingRows,selectedServices.length>0),vehicle:section(vehicleDetailRows,selectedServices.length>0),documents:section(byCategory('documents'),selectedServices.length>0),serviceLicensing:section(licensingRows,licensingRows.length>0),agreement:section(byCategory('agreement')),review:{applicable:true,status:approved?'complete':review?'under_review':actionRequired||openAdmin.length?'action_required':'incomplete'}};
    const applicableSections=Object.values(sectionStatus).filter(item=>item.applicable),completed=applicableSections.filter(item=>item.status==='complete').length,total=applicableSections.length;
    return {selectedServices,vehicleType,automaticRequirements:requirements,adminRequests,warnings,sectionStatus,progress:{completed,total,percentage:total?Math.round(completed/total*100):0},overallStatus,onlineEligibility:{allowed:onlineReasons.length===0,reasons:Array.from(new Set(onlineReasons))},age};
  }
  private static services(profile:any,vehicle:DriverVehicleValidation,onboardingItems:Record<string,unknown>):CanonicalDriverService[]{const raw=profile.driver_service_types||onboardingItems['driver_service_types']||vehicle.serviceEligibility||[];const values=Array.isArray(raw)?raw:String(raw||'').replace(/[\[\]"]/g,'').split(',');return Array.from(new Set(values.map(v=>String(v).trim().toLowerCase()).map(v=>['shop','shopping','errand'].includes(v)?'errand':['deliver','delivery'].includes(v)?'delivery':['move','moving','van','van_moving','van-moving'].includes(v)?'van-moving':v).filter((v):v is CanonicalDriverService=>['ride','delivery','errand','van-moving'].includes(v))));}
  private static onboardingItems(input:unknown):Record<string,unknown>{if(!input)return{};if(typeof input==='string'){try{return this.onboardingItems(JSON.parse(input))}catch{return{}}}if(Array.isArray(input))return input.reduce<Record<string,unknown>>((items,entry)=>{if(!entry||typeof entry!=='object')return items;const row=entry as Record<string,unknown>,key=String(row['key']||row['name']||'').trim();if(key)items[key]=row['value']==='true'?true:row['value']==='false'?false:row['value'];return items;},{});return typeof input==='object'?input as Record<string,unknown>:{};}
  private static vehicle(vehicle:DriverVehicleValidation,profile:any):DriverOperatingVehicle{
    const subtype=String(vehicle.subtype||'').toLowerCase();
    if(subtype==='pedal_bicycle')return'bicycle';
    if(subtype==='e_bike')return'e_bike';
    if(['motorcycle','moped'].includes(subtype))return'motorcycle';
    const value=String(vehicle.capacity||vehicle.type||profile.operating_vehicle||'').toLowerCase();
    if(!value)return null;
    if(/bicycle|bike|cycle/.test(value))return'bicycle';
    if(/motorcycle|motorbike|moped|scooter/.test(value))return'motorcycle';
    if(/large.?van|luton|box.?van/.test(value))return'large_van';
    if(/small.?van|\bvan\b/.test(value))return'small_van';
    return'car';
  }
  private static age(raw:unknown,now:Date,minimum:number){if(!raw)return{eligible:false,years:null,minimum,state:'missing' as const,reason:'Add your date of birth.'};try{const iso=parseDriverDateOfBirth(raw,now),years=calculateCalendarAge(iso,now),eligible=years>=minimum;return{eligible,years,minimum,state:eligible?'completed' as const:'under_age' as const,reason:eligible?null:'You must meet the minimum driver age requirement to register.'};}catch{return{eligible:false,years:null,minimum,state:'invalid' as const,reason:'Enter a valid date of birth.'};}}
  private static has(value:unknown){return String(value??'').trim().length>0;}
  /** Date-only expiry evaluation. A DATE expiring today remains valid today. */
  private static expiryState(expiry: unknown, now: Date): { expired: boolean; expiringSoon: boolean; expiryDate: string | null } {
    const raw = typeof expiry === 'string' ? expiry.trim() : '';
    const dateOnly = raw.slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateOnly)) return { expired: false, expiringSoon: false, expiryDate: null };
    const today = this.toDateOnly(now);
    const expired = dateOnly < today;
    const expiringSoon = !expired && dateOnly <= this.addDays(today, 30);
    return { expired, expiringSoon, expiryDate: dateOnly };
  }
  private static toDateOnly(d: Date): string {
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
  }
  private static addDays(dateOnly: string, days: number): string {
    const [y, m, d] = dateOnly.split('-').map(Number);
    return this.toDateOnly(new Date(Date.UTC(y, m - 1, d + days)));
  }
}
