function t(e){for(let r of[e?.home_address,e?.address_line1,e?.current_address]){let n=typeof r=="string"?r.trim():"";if(n)return n}return""}function d(e){let r=String(e??"").replace(/\r\n?/g,`
`).trim();if(!r||r.length>600)throw Error("Enter a home address using no more than 600 characters.");let n=r.split(`
`).find(s=>s.trim()).trim();if(n.length>250)throw Error("Keep the first address line within 250 characters.");return{home_address:r,address_line1:n}}export{t as a,d as b};
