import{d as r}from"./chunk-T7PXISBH.js";var t=r("Browser",{web:()=>import("./chunk-D266ZHWE.js").then(e=>new e.BrowserWeb)});export{t as a};
