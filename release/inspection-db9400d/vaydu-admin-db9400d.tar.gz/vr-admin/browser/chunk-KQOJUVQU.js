import{c as n}from"./chunk-TDDKBJBY.js";import"./chunk-HU6DUUP4.js";var e=class extends n{async show(o){}async hide(o){}};export{e as SplashScreenWeb};
