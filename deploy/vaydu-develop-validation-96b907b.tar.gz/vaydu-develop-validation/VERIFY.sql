-- Post-apply verification (read-only).
SELECT provider, merchant_account_ref, enabled, preferred, capabilities
  FROM public.market_payment_routes
 WHERE country_code='NG' AND currency_code='NGN' AND method='card';
SELECT count(*) AS flutterwave_ng_rows FROM public.market_payment_routes
 WHERE country_code='NG' AND currency_code='NGN' AND method='card' AND provider='flutterwave';
SELECT relrowsecurity FROM pg_class WHERE oid='public.driver_cash_credit_holds_v1e'::regclass;
SELECT has_table_privilege('authenticated','public.driver_cash_credit_holds_v1e','SELECT') AS authenticated_select;
SELECT count(*) AS reassigned_constraint FROM pg_constraint
 WHERE conrelid='public.driver_cash_credit_holds_v1e'::regclass AND pg_get_constraintdef(oid) LIKE '%reassigned%';
SELECT count(*) AS historical_service_type FROM public.service_types WHERE id='eeeeeeee-1111-2222-3333-444444444444';
