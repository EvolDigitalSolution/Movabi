# Develop-host commands (review only — do not run until approved)

Host: `edsadmin@87.106.64.25`. DB container `movabi-supabase-db`, database
`movabi_develop`; API `movabi-api`; web/admin `movabi-admin`. The live Compose
file chain is discovered from the running container label — do not guess it.

```sh
ssh edsadmin@87.106.64.25
cd ~

# 0. Discover the exact Compose chain currently in use (preserves overrides/secrets)
CFG=$(docker inspect movabi-api --format '{{ index .Config.Labels "com.docker.compose.project.config_files" }}')
echo "$CFG"
COMPOSE_ARGS=$(printf ' -f %s' $CFG)
docker compose $COMPOSE_ARGS config --services   # must list movabi-api, movabi-admin, movabi-supabase-db

# 1. Backup + verification
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
docker exec movabi-supabase-db pg_dump -U postgres -d movabi_develop -Fc > develop-before-$STAMP.dump
docker exec movabi-supabase-db pg_dump -U postgres -d movabi_develop --schema-only > develop-before-$STAMP-schema.sql
sha256sum develop-before-$STAMP.* | tee develop-before-$STAMP.sha256
pg_restore --list develop-before-$STAMP.dump | grep -c 'TABLE DATA'   # > 0 required

# 2. Upload and unpack the bundle
scp -r deploy/vaydu-develop-validation edsadmin@87.106.64.25:~/vaydu-validation-96b907b
sha256sum -c ~/vaydu-validation-96b907b/SHA256SUMS   # run inside the bundle dir
cd ~/vaydu-validation-96b907b

# 3. Read-only prerequisites
docker cp PREREQ.sql movabi-supabase-db:/tmp/PREREQ.sql
docker exec movabi-supabase-db psql -U postgres -d movabi_develop -v ON_ERROR_STOP=1 -f /tmp/PREREQ.sql

# 4. Apply the 19-step manifest in order (each migration is transactional)
while read -r step; do
  docker cp "migrations/$step" movabi-supabase-db:/tmp/"$step"
  docker exec movabi-supabase-db psql -U postgres -d movabi_develop -v ON_ERROR_STOP=1 -q -f /tmp/"$step" \
    || { echo "FAILED: $step"; exit 1; }
  echo "applied $step"
done < ORDER.txt

# 5. Verify
docker cp VERIFY.sql movabi-supabase-db:/tmp/VERIFY.sql
docker exec movabi-supabase-db psql -U postgres -d movabi_develop -v ON_ERROR_STOP=1 -f /tmp/VERIFY.sql

# 6. Roll out API and web/admin from the frozen build (after migrations pass)
docker compose $COMPOSE_ARGS up -d --build movabi-api movabi-admin
docker compose $COMPOSE_ARGS ps
docker exec movabi-api node -e "fetch('http://127.0.0.1:'+(process.env.PORT||3000)+'/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"
```

## Recovery — three separate cases

### A. Pre-traffic migration failure (no new traffic yet)

- Each migration is transactional; a failure aborts only that step. Earlier
  steps remain committed. Do **not** restore the backup if no post-migration
  writes occurred.
- Fix the failing step, re-run from that step; re-running an applied step is
  guarded by its own idempotency checks and will fail closed on divergence.
- If the failure is structural and cannot be corrected, stop, restore the
  backup, and re-run the clone rehearsal before any new attempt.

### B. Application rollback (traffic already on the new schema)

- Rolling the API/web back does **not** require a database restore. The manifest
  is additive; old code ignores new tables/functions.
- Preserve new financial rows: never delete holds, routes or wallet events.
- Re-deploy the previous image tag with the same Compose chain, keep the schema,
  and verify old-code compatibility by running the deployed smoke checks that
  old code supports (quote/create, feed isolation, completion with PIN).
- If old code cannot tolerate a new constraint, fix forward; do not drop the
  constraint and erase history.

### C. Database restore (disaster or isolated drill only)

- Restore is **never** an automatic rollback. A restore erases legitimate
  post-deployment financial activity if used after go-live.
- Drill only against an isolated clone: `createdb movabi_drill`,
  `pg_restore -d movabi_drill develop-before-$STAMP.dump`, verify table/data
  counts and RLS/grants, then drop the drill database.
- Production restore requires incident lead approval, write freeze, and a
  reconciliation of transactions created after the backup timestamp.
