# Build results — candidate `96b907b`

Run from the clean frozen snapshot (branch `v2.3`, HEAD `96b907b`), no
uncommitted changes to tracked sources.

| Build | Command | Exit | Output |
|---|---|---|---|
| Mobile (develop) | `npm run build:mobile:develop` | 0 | `dist/mobile` (68.439 s) |
| Admin | `npm run build:admin` | 0 | `dist/admin` |
| Server typecheck | `npx tsc --noEmit -p server/tsconfig.json` | 0 (0 errors) | — |
| Authenticated Bike/cash suite | `npx vitest run src/testing/bike-authenticated-routes.integration.spec.ts` | 0 (110.5 s) | — |
| Wallet/settlement harness | 5 specs incl. `batch2c-settlement-behavior` | 0 (52 tests) | — |

Artifact checksums (index files) are in `SHA256SUMS`; full `dist` trees are build
outputs and are not committed. Rebuild from the same SHA to reproduce them.
