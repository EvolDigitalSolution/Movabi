-- Read-only prerequisites. Expect: one Kora row, zero Flutterwave NG rows, objects present.
SELECT country_code,currency_code,method,provider,merchant_account_ref,enabled,capabilities
  FROM public.market_payment_routes
 WHERE country_code='NG' AND currency_code='NGN' AND method='card';
SELECT count(*) AS flutterwave_ng_rows
  FROM public.market_payment_routes
 WHERE country_code='NG' AND currency_code='NGN' AND method='card' AND provider='flutterwave';
SELECT to_regclass('public.wallet_topup_attempts') AS wallet_attempts,
       to_regclass('public.quote_market_adjustments') AS quote_audit,
       to_regclass('public.profiles') AS profiles,
       to_regclass('public.jobs') AS jobs;
