-- Called only after the operator validates private dashboard evidence, matching
-- private TEST binding, image/API proof and clone proof.
BEGIN;
SELECT set_config('vaydu.merchant',:'merchant',true);
SELECT set_config('vaydu.evidence',:'evidence',true);
DO $$ DECLARE n integer;BEGIN
 IF current_database()<>'movabi_develop'
 OR to_regprocedure('public.fence_driver_payment_setup(uuid,uuid,text,text,text)') IS NULL
 OR current_setting('vaydu.evidence') !~ '^operator-dashboard-sha256:[a-f0-9]{64}$'
 THEN RAISE EXCEPTION 'Verified setup prerequisites required';END IF;
 UPDATE public.driver_payout_markets SET enabled=true,merchant_approved=true,adapter_ready=true,
 capability_verified_at=now(),capability_evidence_ref=current_setting('vaydu.evidence')
 WHERE country_code='NG' AND currency_code='NGN' AND provider='flutterwave' AND merchant_mode='test'
 AND merchant_account_ref=current_setting('vaydu.merchant')
 AND sandbox_driver_id='318e6be9-9164-41fa-bb0c-c5ccd3526585'
 AND sandbox_tenant_id='d0e8e8e8-e8e8-e8e8-e8e8-d0e8e8e8e8e8';
 GET DIAGNOSTICS n=ROW_COUNT;
 IF n<>1 OR (SELECT count(*) FROM public.driver_payout_markets WHERE enabled)<>1 THEN RAISE EXCEPTION 'Exactly one approved setup scope required';END IF;
END $$;
COMMIT;
