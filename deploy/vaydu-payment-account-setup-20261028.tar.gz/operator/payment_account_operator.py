"""Setup-only driver payment-account operator for the Vaydu develop API.

Stages
------
status            read-only JSON report
preflight         fail-closed read-only checks (no writes)
rehearse          fresh backup -> disposable network-none PostgreSQL 15 restore
                  -> apply canonical SQL -> repeat/refusal -> preservation -> cleanup
build             derive an API image from the reviewed deployed baseline + closure
test-api          isolated 127.0.0.1 container tests (401/status), then cleanup
deploy-disabled   record the exact Compose chain + original image, recreate API only
activate          apply canonical SQL + setup-only environment (no transfers)
verify            hosted checks for the setup-only route
rollback          restore the recorded original image and environment

Safety: setup is separated from money movement. No transfer, payout dispatch,
wallet credit, collection, subaccount or split operation is performed here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import uuid
from pathlib import Path

DRIVER = "318e6be9-9164-41fa-bb0c-c5ccd3526585"
TENANT = "d0e8e8e8-e8e8-e8e8-e8e8-d0e8e8e8e8e8"
STATE = Path.home() / ".local/state/vaydu-payment-account-operator"
ROOT = Path(__file__).resolve().parent.parent
SQL = ROOT / "sql" / "payment_account_setup_canonical.sql"
RELEASE = ROOT / "release.json"
MANIFEST = ROOT / "manifest.sha256"
API_DOCKERFILE = ROOT / "Dockerfile.api"
HOSTED = "https://movabi-develop.apps.evolsolution.com"
DB_CONTAINER = "movabi-develop-db"
DB_NAME = "movabi_develop"
POSTGRES_IMAGE = "postgres:15"


class Blocked(Exception):
    pass


def run(args, data=None, timeout=600):
    proc = subprocess.run(args, input=data, capture_output=True, timeout=timeout)
    if proc.returncode:
        raise Blocked("command_failed:" + Path(args[0]).name)
    return proc.stdout.decode().strip()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def load(path: Path, default=None):
    return json.loads(Path(path).read_text()) if Path(path).is_file() else default


def save(name: str, value: dict) -> None:
    STATE.mkdir(parents=True, mode=0o700, exist_ok=True)
    if STATE.is_symlink() or os.stat(STATE).st_uid != os.getuid():
        raise Blocked("unsafe_operator_state")
    target = STATE / name
    if target.is_symlink():
        raise Blocked("unsafe_operator_state")
    temp = STATE / (name + ".tmp-" + uuid.uuid4().hex[:8])
    temp.write_text(json.dumps(value, indent=2) + "\n")
    os.chmod(temp, 0o600)
    os.replace(temp, target)


def load_release() -> dict:
    manifest = load(MANIFEST)
    if not manifest:
        raise Blocked("release_manifest_missing")
    for line in MANIFEST.read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = ROOT / name
        if path.is_symlink() or not path.is_file() or digest(path) != expected:
            raise Blocked("release_checksum_mismatch:" + name)
    release = load(RELEASE, {})
    if release.get("purpose") != "vaydu-driver-payment-account-setup-v1":
        raise Blocked("wrong_release_purpose")
    if release.get("driver") != DRIVER or release.get("tenant") != TENANT:
        raise Blocked("wrong_release_scope")
    if not re.fullmatch(r"sha256:[a-f0-9]{64}", release.get("baselineApiImage", "")):
        raise Blocked("reviewed_baseline_image_required")
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,120}", release.get("merchantRef", "")):
        raise Blocked("merchant_reference_required")
    if digest(SQL) != release.get("sqlSha256"):
        raise Blocked("canonical_sql_checksum_mismatch")
    return release


def docker() -> list[str]:
    probe = subprocess.run(["docker", "info", "--format", "{{.ServerVersion}}"], capture_output=True)
    return ["docker"] if probe.returncode == 0 else ["sudo", "-n", "docker"]


def sql_read(statement: str) -> str:
    d = docker()
    proc = subprocess.run(
        d + ["exec", "-i", DB_CONTAINER, "psql", "-X", "-U", "postgres", "-d", DB_NAME, "-qAt",
             "-v", "ON_ERROR_STOP=1",
             "-c", "SET default_transaction_read_only=on; SET search_path=pg_catalog,public; " + statement],
        capture_output=True, timeout=120)
    if proc.returncode:
        raise Blocked("read_query_failed")
    return proc.stdout.decode().strip()


def sql_apply(statements: dict, script: Path | None = None) -> tuple[bool, str]:
    d = docker()
    args = d + ["exec", "-i", DB_CONTAINER, "psql", "-X", "-U", "postgres", "-d", DB_NAME, "-q",
                "-v", "ON_ERROR_STOP=1"]
    for key, value in statements.items():
        args += ["-v", f"{key}={value}"]
    if script is not None:
        payload = script.read_bytes()
        args += ["-f", "-"]
        proc = subprocess.run(args, input=payload, capture_output=True, timeout=180)
    else:
        proc = subprocess.run(args, input=b"", capture_output=True, timeout=180)
    return proc.returncode == 0, proc.stderr.decode(errors="replace")


def schema_state() -> dict:
    row = sql_read(
        "SELECT json_build_object("
        "'markets',to_regclass('public.driver_payout_markets') IS NOT NULL,"
        "'accounts',to_regclass('public.driver_payment_accounts') IS NOT NULL,"
        "'claim',to_regprocedure('public.claim_driver_payment_setup(uuid,uuid,text,text,text)') IS NOT NULL)"
    )
    return json.loads(row)


def classify_schema(state: dict) -> str:
    parts = [state.get("markets"), state.get("accounts"), state.get("claim")]
    if parts == [False, False, False]:
        return "absent"
    if parts == [True, True, True]:
        return "complete"
    return "partial"


def preflight(release: dict, strict: bool = True) -> dict:
    if sql_read("SELECT current_database()") != DB_NAME:
        raise Blocked("wrong_database")
    if sql_read("SELECT count(*) FROM public.profiles WHERE id='%s' AND tenant_id='%s' AND role='driver' "
                "AND registration_activated_at IS NOT NULL "
                "AND coalesce(registration_country_code,country_code)='NG'" % (DRIVER, TENANT)) != "1":
        raise Blocked("approved_driver_scope_required")
    ng = sql_read("SELECT count(DISTINCT upper(supported_currency))||'|'||max(upper(supported_currency)) "
                  "FROM public.market_availability WHERE country_code='NG'")
    if ng != "1|NGN":
        raise Blocked("ng_currency_must_be_ngn")
    state = classify_schema(schema_state())
    if state == "partial":
        raise Blocked("partial_schema_requires_reconciliation")
    # Money movement must be disabled and the payout queue quiet.
    if sql_read("SELECT count(*) FROM public.job_payout_queue WHERE status IN ('pending','processing','reconcile')") != "0":
        raise Blocked("payout_queue_not_quiet")
    enabled_markets = "0"
    if strict and state != "absent":
        enabled_markets = sql_read("SELECT count(*) FROM public.driver_payout_markets WHERE enabled")
        if enabled_markets != "0":
            raise Blocked("payout_market_already_enabled")
    for flag in ("VAYDU_DRIVER_PAYOUT_TRANSFERS", "VAYDU_DRIVER_SUBACCOUNT_SANDBOX", "VAYDU_FLUTTERWAVE_BOOKING_SPLIT_SANDBOX"):
        if os.environ.get(flag) == "true":
            raise Blocked("money_movement_flag_forbidden_during_onboarding:" + flag)
    return {
        "database": DB_NAME,
        "driver": DRIVER,
        "tenant": TENANT,
        "schemaState": state,
        "enabledPayoutMarkets": int(enabled_markets),
        "payoutQueueQuiet": True,
        "moneyMovementFlagsOff": True,
        "baselineApiImage": release["baselineApiImage"],
    }


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def _wait_http(port: int, path: str, timeout: float = 90.0) -> int:
    import http.client
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        try:
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
            conn.request("GET", path)
            last = conn.getresponse().status
            conn.close()
            if last:
                return last
        except OSError:
            last = None
        time.sleep(0.5)
    raise Blocked("api_not_ready")


def rehearse(release: dict) -> dict:
    d = docker()
    backups = Path.home() / "vaydu-develop-wallet-backups"
    backups.mkdir(parents=True, mode=0o700, exist_ok=True)
    dump = backups / ("rehearsal-" + uuid.uuid4().hex[:8] + ".dump")
    container = "vaydu-pa-rehearsal-" + uuid.uuid4().hex[:8]
    try:
        with dump.open("wb") as handle:
            proc = subprocess.run(d + ["exec", DB_CONTAINER, "pg_dump", "-Fc", "-U", "postgres", DB_NAME],
                                  stdout=handle, stderr=subprocess.PIPE, timeout=900)
        if proc.returncode or dump.stat().st_size == 0:
            raise Blocked("fresh_backup_failed")
        os.chmod(dump, 0o600)
        restore = subprocess.run(
            d + ["run", "-d", "--rm", "--name", container, "--network", "none",
                 "-e", "POSTGRES_PASSWORD=rehearsal", "-e", "POSTGRES_DB=" + DB_NAME, POSTGRES_IMAGE],
            capture_output=True, timeout=120)
        if restore.returncode:
            raise Blocked("rehearsal_container_start_failed")
        _wait_pg(container, d)
        with dump.open("rb") as handle:
            proc = subprocess.run(d + ["exec", "-i", container, "pg_restore", "-U", "postgres", "-d", DB_NAME,
                                       "--no-owner", "--no-privileges"], stdin=handle,
                                 capture_output=True, timeout=900)
        # Ownership/ACL preservation is intentionally not verified here because
        # --no-owner/--no-privileges is used; the real proof is the canonical
        # apply/repeat/refusal on restored data below.
        before = _protected(d, container)
        args = ["exec", "-i", container, "psql", "-X", "-U", "postgres", "-d", DB_NAME, "-q",
                "-v", "ON_ERROR_STOP=1", "-v", "driver=" + DRIVER, "-v", "tenant=" + TENANT,
                "-v", "merchant=" + release["merchantRef"], "-v", "evidence=" + release["evidenceRef"]]
        first = subprocess.run(d + args + ["-f", "-"], input=SQL.read_bytes(), capture_output=True, timeout=180)
        if first.returncode:
            raise Blocked("canonical_apply_failed_in_rehearsal")
        second = subprocess.run(d + args + ["-f", "-"], input=SQL.read_bytes(), capture_output=True, timeout=180)
        if second.returncode == 0:
            raise Blocked("repeat_apply_must_refuse")
        after = _protected(d, container)
        if before != after:
            raise Blocked("protected_fingerprint_changed")
        proof = {
            "sourceKind": "verified-develop",
            "sourceContainer": DB_CONTAINER,
            "sourceDatabase": DB_NAME,
            "restoreVerified": True,
            "canonicalApplyVerified": True,
            "repeatApplyRefused": True,
            "protectedUnchanged": True,
            "sqlSha256": digest(SQL),
            "backupSha256": digest(dump),
            "verifiedAt": time.time(),
        }
        save("rehearsal.json", proof)
        return proof
    finally:
        subprocess.run(d + ["rm", "-f", container], capture_output=True, timeout=60)
        if dump.exists():
            dump.unlink()


def _wait_pg(container: str, d: list[str], timeout: float = 90.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        proc = subprocess.run(d + ["exec", container, "pg_isready", "-U", "postgres"], capture_output=True)
        if proc.returncode == 0:
            return
        time.sleep(0.5)
    raise Blocked("rehearsal_postgres_not_ready")


def _protected(d: list[str], container: str) -> str:
    """Fingerprint the protected booking/Stripe/routing authority, excluding new objects."""
    statement = (
        "SELECT md5(coalesce((SELECT jsonb_agg(jsonb_build_array(p.oid::regprocedure::text,"
        "pg_get_functiondef(p.oid)) ORDER BY p.oid::regprocedure::text)::text FROM pg_proc p "
        "JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' "
        "AND p.proname NOT IN('guard_driver_payment_account_identity','claim_driver_payment_setup')),'[]'))||"
        "'|'||(SELECT count(*) FROM public.market_payment_routes)||'|'||"
        "(SELECT count(*) FROM public.job_payout_queue)"
    )
    proc = subprocess.run(d + ["exec", "-i", container, "psql", "-X", "-U", "postgres", "-d", DB_NAME,
                               "-qAt", "-v", "ON_ERROR_STOP=1", "-c", statement],
                          capture_output=True, timeout=120)
    if proc.returncode:
        raise Blocked("protected_fingerprint_unavailable")
    return proc.stdout.decode().strip()


def build(release: dict) -> dict:
    d = docker()
    tag = "vaydu-api:payment-account-setup-" + uuid.uuid4().hex[:8]
    proc = subprocess.run(
        d + ["build", "--network", "none", "--pull=false",
             "--build-arg", "BASELINE=" + release["baselineApiImage"],
             "--tag", tag, "--file", str(API_DOCKERFILE), str(ROOT)],
        capture_output=True, timeout=900)
    if proc.returncode:
        raise Blocked("api_image_build_failed")
    image = run(d + ["image", "inspect", "--format", "{{.Id}}", tag])
    if not re.fullmatch(r"sha256:[a-f0-9]{64}", image):
        raise Blocked("api_image_identity_invalid")
    save("built-image.json", {"image": image, "baseline": release["baselineApiImage"], "builtAt": time.time()})
    return {"image": image, "baseline": release["baselineApiImage"]}


def test_api(release: dict, built: dict) -> dict:
    d = docker()
    container = "vaydu-pa-api-test-" + uuid.uuid4().hex[:8]
    port = _free_port()
    try:
        proc = subprocess.run(
            d + ["run", "-d", "--rm", "--name", container, "--network", "none",
                 "-p", f"127.0.0.1:{port}:3001", built["image"]],
            capture_output=True, timeout=120)
        if proc.returncode:
            raise Blocked("api_test_container_start_failed")
        _wait_http(port, "/health")
        status = _wait_http(port, "/api/driver-payment-account/status")
        if status != 401:
            raise Blocked("setup_route_must_require_auth")
        return {"image": built["image"], "unauthStatus": status, "ok": True}
    finally:
        subprocess.run(d + ["rm", "-f", container], capture_output=True, timeout=60)


def target(d: list[str]) -> dict:
    records = {}
    for kind, name in (("api", "movabi-develop-api"), ("web", "movabi-develop-web")):
        def meta(fmt: str, container: str = name) -> str:
            return run(d + ["inspect", "--format", fmt, container])

        def label(key: str, container: str = name) -> str:
            return meta('{{index .Config.Labels "com.docker.compose.' + key + '"}}', container)

        if label("project") != "movabi-develop":
            raise Blocked("compose_project_changed")
        files = [f for f in label("project.config_files").split(",") if f]
        directory = label("project.working_dir")
        service = label("service")
        if not re.fullmatch(r"[A-Za-z0-9_-]+", service) or not Path(directory).is_dir():
            raise Blocked("compose_chain_unavailable")
        if any(not Path(f).is_absolute() or not Path(f).is_file() for f in files):
            raise Blocked("compose_chain_unavailable")
        records[kind] = {
            "container": name,
            "image": meta("{{.Image}}"),
            "service": service,
            "directory": directory,
            "files": files,
            "fileHashes": {f: digest(Path(f)) for f in files},
        }
    if records["api"]["service"] == records["web"]["service"]:
        raise Blocked("api_web_service_collision")
    return records


def compose(d: list[str], record: dict, override: Path) -> None:
    for file, expected in record["fileHashes"].items():
        if digest(Path(file)) != expected:
            raise Blocked("compose_chain_changed")
    cmd = d + ["compose", "--project-name", "movabi-develop", "--project-directory", record["directory"]]
    for file in record["files"]:
        cmd += ["-f", file]
    run(cmd + ["-f", str(override), "up", "-d", "--no-deps", "--no-build", "--pull", "never",
               "--force-recreate", record["service"]])


def override_payload(service: str, image: str, environment: dict | None = None) -> dict:
    payload: dict = {"services": {service: {"image": image}}}
    if environment:
        payload["services"][service]["environment"] = environment
    return payload


def deploy_disabled(release: dict, built: dict) -> dict:
    d = docker()
    current = target(d)
    api = current["api"]
    save("baseline.json", current)
    override = STATE / "api-disabled.override.json"
    save(override.name, override_payload(api["service"], built["image"]))
    compose(d, api, override)
    after = target(d)["api"]
    if after["image"] != built["image"]:
        raise Blocked("running_api_image_mismatch")
    if run(d + ["inspect", "--format", "{{.State.Status}}", after["container"]]) != "running":
        raise Blocked("api_not_running_after_deploy")
    save("deployed.json", {"image": built["image"], "originalImage": api["image"], "service": api["service"],
                           "record": api, "setupEnabled": False, "deployedAt": time.time()})
    return {"image": built["image"], "originalImage": api["image"], "service": api["service"], "setupEnabled": False}


def activate(release: dict) -> dict:
    deployed = load(STATE / "deployed.json", {})
    if deployed.get("image") != load(STATE / "built-image.json", {}).get("image"):
        raise Blocked("deploy_disabled_required_first")
    state = classify_schema(schema_state())
    if state == "partial":
        raise Blocked("partial_schema_requires_reconciliation")
    if state == "absent":
        raise Blocked("install_required_first")
    if sql_read("SELECT count(*) FROM public.driver_payout_markets WHERE enabled") == "0":
        activate_sql = SQL.parent / "payment_account_activate.sql"
        if not activate_sql.is_file():
            raise Blocked("activation_sql_missing")
        ok, _ = sql_apply({"driver": DRIVER, "tenant": TENANT, "merchant": release["merchantRef"]}, script=activate_sql)
        if not ok:
            raise Blocked("canonical_activation_failed")
    d = docker()
    record = deployed["record"]
    environment = {
        # Setup-only. Transfers and dispatch stay explicitly off.
        "VAYDU_DRIVER_PAYOUT_SANDBOX": "true",
        "VAYDU_DRIVER_PAYOUT_TRANSFERS": "false",
    }
    override = STATE / "api-setup.override.json"
    save(override.name, override_payload(record["service"], deployed["image"], environment))
    compose(d, record, override)
    after = target(d)["api"]
    if after["image"] != deployed["image"]:
        raise Blocked("running_api_image_mismatch")
    scope = sql_read("SELECT count(*)||'|'||bool_and(enabled) FROM public.driver_payout_markets "
                     "WHERE country_code='NG' AND currency_code='NGN' AND sandbox_driver_id='%s' AND sandbox_tenant_id='%s'"
                     % (DRIVER, TENANT))
    if scope != "1|true":
        raise Blocked("approved_scope_not_active")
    save("activated.json", {"image": deployed["image"], "scope": scope, "transfers": False, "activatedAt": time.time()})
    return {"image": deployed["image"], "scopeActive": True, "transfersEnabled": False, "schemaState": schema_state()}


def verify(release: dict) -> dict:
    import urllib.error
    import urllib.request

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **kw):
            return None

    opener = urllib.request.build_opener(NoRedirect())
    checks = {}
    for path, expected in (("/api/driver-payment-account/status", 401), ("/api/driver-onboarding/status", 401)):
        try:
            with opener.open(HOSTED + path, timeout=15) as response:
                checks[path] = response.status
        except urllib.error.HTTPError as error:
            checks[path] = error.code
        if checks[path] != expected:
            raise Blocked("unexpected_status:" + path)
    if sql_read("SELECT count(*) FROM public.job_payout_queue WHERE status IN ('pending','processing','reconcile')") != "0":
        raise Blocked("payout_queue_not_quiet")
    save("verified.json", {"checks": checks, "verifiedAt": time.time()})
    return {"checks": checks, "payoutQueueQuiet": True}


def rollback() -> dict:
    d = docker()
    deployed = load(STATE / "deployed.json", {})
    if not deployed.get("record") or not re.fullmatch(r"sha256:[a-f0-9]{64}", deployed.get("originalImage", "")):
        raise Blocked("rollback_receipt_missing")
    override = STATE / "api-rollback.override.json"
    save(override.name, override_payload(deployed["record"]["service"], deployed["originalImage"]))
    compose(d, deployed["record"], override)
    if target(d)["api"]["image"] != deployed["originalImage"]:
        raise Blocked("rollback_image_mismatch")
    return {"restoredImage": deployed["originalImage"]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["status", "preflight", "install", "rehearse", "build", "test-api",
                                          "deploy-disabled", "activate", "verify", "rollback"])
    args = parser.parse_args()
    release = load_release()
    if args.stage == "status":
        print(json.dumps({"stage": "status", "schemaState": classify_schema(schema_state()),
                          "driver": DRIVER, "tenant": TENANT, "baselineApiImage": release["baselineApiImage"]}))
        return 0
    report = preflight(release, strict=args.stage in ("preflight", "install", "rehearse", "build", "test-api", "deploy-disabled"))
    if args.stage == "preflight":
        print(json.dumps({"stage": "preflight", **report}))
        return 0
    if args.stage == "install":
        state = classify_schema(schema_state())
        if state == "partial":
            raise Blocked("partial_schema_requires_reconciliation")
        if state == "absent":
            ok, _ = sql_apply({"driver": DRIVER, "tenant": TENANT, "merchant": release["merchantRef"],
                               "evidence": release["evidenceRef"]}, script=SQL)
            if not ok:
                raise Blocked("canonical_install_failed")
        scope = sql_read("SELECT count(*)||'|'||coalesce(bool_and(enabled)::text,'false') "
                         "FROM public.driver_payout_markets WHERE country_code='NG' AND currency_code='NGN'")
        print(json.dumps({"stage": "install", "schemaState": classify_schema(schema_state()),
                          "scope": scope, "enabled": scope.endswith("|true")}))
        return 0
    if args.stage == "rehearse":
        print(json.dumps({"stage": "rehearse", **rehearse(release)}))
        return 0
    if args.stage == "build":
        print(json.dumps({"stage": "build", **build(release)}))
        return 0
    if args.stage == "test-api":
        built = load(STATE / "built-image.json", {})
        if not built.get("image"):
            raise Blocked("build_required_first")
        print(json.dumps({"stage": "test-api", **test_api(release, built)}))
        return 0
    if args.stage == "deploy-disabled":
        built = load(STATE / "built-image.json", {})
        if not built.get("image"):
            raise Blocked("build_required_first")
        print(json.dumps({"stage": "deploy-disabled", **deploy_disabled(release, built)}))
        return 0
    if args.stage == "activate":
        print(json.dumps({"stage": "activate", **activate(release)}))
        return 0
    if args.stage == "verify":
        print(json.dumps({"stage": "verify", **verify(release)}))
        return 0
    print(json.dumps({"stage": "rollback", **rollback()}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Blocked as error:
        print(json.dumps({"completed": False, "blocked": str(error), "rawOutputWithheld": True}))
        raise SystemExit(1)

