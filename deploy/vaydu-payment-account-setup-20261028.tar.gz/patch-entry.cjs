﻿// Guarded mount: inject exactly one payment-account route into the baseline entry.
const fs = require('fs');
const candidates = ['/app/dist/index.js', '/app/server/index.js', '/app/index.js'];
const entry = candidates.find(p => fs.existsSync(p));
if (!entry) { console.error('entry_not_found'); process.exit(2); }
let source = fs.readFileSync(entry, 'utf8');
if (source.includes("driver-payment-account-closure/mount")) { console.log('already_mounted'); process.exit(0); }
const anchor = source.indexOf('app.listen(');
if (anchor < 0) { console.error('listen_anchor_not_found'); process.exit(3); }
const mount = "require('/app/server/payment-account-closure/mount.cjs')(app);\n";
source = source.slice(0, anchor) + mount + source.slice(anchor);
fs.writeFileSync(entry, source);
console.log('mounted');
