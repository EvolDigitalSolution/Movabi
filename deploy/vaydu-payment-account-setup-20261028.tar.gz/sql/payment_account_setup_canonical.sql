-- =============================================================================
-- Vaydu driver payment-account setup (canonical additive, setup-only)
--
-- Scope: ONE approved sandbox driver/tenant in NG/NGN. Creates only the
-- payment-account setup schema/functions and the approved scope row.
--
-- Deliberately EXCLUDED (separate reviews required):
--   * market_payment_routes changes / collection-preferred rewrites
--   * payout outbox, payout worker, transfers
--   * collection subaccounts, booking splits, wallet credit
--
-- Apply with psql variables, e.g.:
--   psql -v driver=… -v tenant=… -v merchant=… -v evidence=… -f this.sql
--
-- States:
--   absent   -> apply
--   complete -> refuse (idempotent no-op is an operator decision, not SQL)
--   partial  -> refuse (reconcile before applying)
-- =============================================================================
BEGIN;

-- psql variables are not interpolated inside dollar-quoted blocks, so publish
-- them as transaction-local settings first.
SELECT set_config('vaydu.driver', :'driver', true);
SELECT set_config('vaydu.tenant', :'tenant', true);
SELECT set_config('vaydu.merchant', :'merchant', true);
SELECT set_config('vaydu.evidence', :'evidence', true);

DO $preflight$
DECLARE
  v_driver text := current_setting('vaydu.driver');
  v_tenant text := current_setting('vaydu.tenant');
  v_merchant text := current_setting('vaydu.merchant');
  v_evidence text := current_setting('vaydu.evidence');
  missing text[] := ARRAY[]::text[];
BEGIN
  IF current_database() <> 'movabi_develop' THEN
    RAISE EXCEPTION 'Develop database required';
  END IF;
  IF to_regclass('public.profiles') IS NULL THEN missing := missing || ARRAY['public.profiles']; END IF;
  IF to_regclass('public.market_availability') IS NULL THEN missing := missing || ARRAY['public.market_availability']; END IF;
  IF cardinality(missing) > 0 THEN
    RAISE EXCEPTION 'Missing required base tables: %', array_to_string(missing, ', ');
  END IF;

  IF v_driver !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
     OR v_tenant !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN
    RAISE EXCEPTION 'Valid driver and tenant UUIDs are required';
  END IF;
  IF length(btrim(v_merchant)) = 0 OR v_merchant <> btrim(v_merchant) THEN
    RAISE EXCEPTION 'Merchant reference is required';
  END IF;
  IF length(btrim(v_evidence)) = 0 THEN
    RAISE EXCEPTION 'Capability evidence reference is required (never auto-approve)';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.profiles p
     WHERE p.id = v_driver::uuid AND p.tenant_id = v_tenant::uuid AND p.role = 'driver'
       AND p.registration_activated_at IS NOT NULL
       AND coalesce(p.registration_country_code, p.country_code) = 'NG'
  ) THEN
    RAISE EXCEPTION 'Approved activated NG driver/tenant scope required';
  END IF;
  IF (SELECT count(DISTINCT upper(supported_currency)) FROM public.market_availability WHERE country_code='NG') <> 1
     OR (SELECT max(upper(supported_currency)) FROM public.market_availability WHERE country_code='NG') <> 'NGN' THEN
    RAISE EXCEPTION 'NG market currency must be unambiguous NGN';
  END IF;

  IF to_regclass('public.driver_payout_markets') IS NOT NULL
     AND to_regclass('public.driver_payment_accounts') IS NOT NULL
     AND to_regprocedure('public.claim_driver_payment_setup(uuid,uuid,text,text,text)') IS NOT NULL THEN
    RAISE EXCEPTION 'Payment-account setup schema is already complete; refusing to re-apply';
  END IF;
  IF (to_regclass('public.driver_payout_markets') IS NOT NULL)
     <> (to_regclass('public.driver_payment_accounts') IS NOT NULL)
     OR (to_regclass('public.driver_payment_accounts') IS NOT NULL
         AND to_regprocedure('public.claim_driver_payment_setup(uuid,uuid,text,text,text)') IS NULL) THEN
    RAISE EXCEPTION 'Partial payment-account setup schema; reconcile before applying';
  END IF;
END
$preflight$;

CREATE TABLE public.driver_payout_markets(
  country_code text NOT NULL,
  currency_code text NOT NULL,
  provider text NOT NULL CHECK (provider IN ('stripe','flutterwave','kora','fincra')),
  merchant_account_ref text,
  enabled boolean NOT NULL DEFAULT false,
  merchant_approved boolean NOT NULL DEFAULT false,
  adapter_ready boolean NOT NULL DEFAULT false,
  capability_verified_at timestamptz,
  capability_evidence_ref text,
  merchant_mode text NOT NULL DEFAULT 'test' CHECK (merchant_mode = 'test'),
  sandbox_driver_id uuid,
  sandbox_tenant_id uuid,
  PRIMARY KEY (country_code, currency_code),
  CHECK (NOT enabled OR (merchant_approved AND adapter_ready AND merchant_account_ref IS NOT NULL
    AND capability_verified_at IS NOT NULL AND capability_evidence_ref IS NOT NULL
    AND sandbox_driver_id IS NOT NULL AND sandbox_tenant_id IS NOT NULL)),
  CHECK (provider <> 'flutterwave' OR NOT enabled OR (country_code = 'NG' AND currency_code = 'NGN'))
);

CREATE TABLE public.driver_payment_accounts(
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid NOT NULL REFERENCES public.profiles(id),
  tenant_id uuid NOT NULL,
  country_code text NOT NULL,
  currency_code text NOT NULL,
  provider text NOT NULL DEFAULT 'flutterwave' CHECK (provider = 'flutterwave'),
  merchant_account_ref text NOT NULL,
  state text NOT NULL CHECK (state IN ('not_started','in_progress','action_required','reconciliation_required','completed','unavailable')),
  beneficiary_id text,
  bank_code text,
  last4 text CHECK (last4 ~ '^\d{4}$'),
  fingerprint text,
  setup_token uuid NOT NULL DEFAULT gen_random_uuid(),
  submission_attempted_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (driver_id, tenant_id, country_code, currency_code, merchant_account_ref),
  CHECK (state <> 'completed' OR (
    beneficiary_id IS NOT NULL AND fingerprint IS NOT NULL
    AND beneficiary_id ~ '^\d+$' AND bank_code IS NOT NULL AND last4 IS NOT NULL
    AND fingerprint ~ '^[a-f0-9]{64}$'))
);

ALTER TABLE public.driver_payout_markets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_payment_accounts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.driver_payout_markets, public.driver_payment_accounts FROM PUBLIC, anon, authenticated, service_role;
GRANT SELECT ON public.driver_payout_markets TO service_role;
GRANT SELECT, UPDATE ON public.driver_payment_accounts TO service_role;

CREATE FUNCTION public.guard_driver_payment_account_identity() RETURNS trigger
LANGUAGE plpgsql SET search_path = public, pg_temp AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Retain payment account history';
  END IF;
  IF (NEW.id, NEW.driver_id, NEW.tenant_id, NEW.country_code, NEW.currency_code, NEW.provider, NEW.merchant_account_ref)
     IS DISTINCT FROM
     (OLD.id, OLD.driver_id, OLD.tenant_id, OLD.country_code, OLD.currency_code, OLD.provider, OLD.merchant_account_ref)
     OR (OLD.state = 'completed' AND (NEW.beneficiary_id, NEW.bank_code, NEW.last4, NEW.fingerprint, NEW.state)
         IS DISTINCT FROM (OLD.beneficiary_id, OLD.bank_code, OLD.last4, OLD.fingerprint, OLD.state))
  THEN
    RAISE EXCEPTION 'Frozen payment account identity cannot change';
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER guard_driver_payment_account_identity
BEFORE UPDATE OR DELETE ON public.driver_payment_accounts
FOR EACH ROW EXECUTE FUNCTION public.guard_driver_payment_account_identity();

REVOKE ALL ON FUNCTION public.guard_driver_payment_account_identity() FROM PUBLIC, anon, authenticated, service_role;

-- Idempotent, owner-scoped claim. A fresh setup_token fences concurrent or
-- crashed attempts; an in-progress row younger than five minutes is retained.
CREATE FUNCTION public.claim_driver_payment_setup(
  p_driver uuid, p_tenant uuid, p_country text, p_currency text, p_merchant text
) RETURNS SETOF public.driver_payment_accounts
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
      FROM public.driver_payout_markets m
      JOIN public.profiles p ON p.id = p_driver
     WHERE m.country_code = p_country AND m.currency_code = p_currency
       AND m.provider = 'flutterwave' AND m.enabled AND m.merchant_approved AND m.adapter_ready
       AND m.capability_verified_at IS NOT NULL AND m.capability_evidence_ref IS NOT NULL
       AND m.merchant_mode = 'test' AND m.merchant_account_ref = p_merchant
       AND m.sandbox_driver_id = p_driver AND m.sandbox_tenant_id = p_tenant
       AND p.tenant_id = p_tenant AND p.role = 'driver' AND p.registration_activated_at IS NOT NULL
       AND coalesce(p.registration_country_code, p.country_code) = p_country
  ) THEN
    RAISE EXCEPTION 'Approved sandbox driver market required';
  END IF;
  RETURN QUERY
  INSERT INTO public.driver_payment_accounts(
    driver_id, tenant_id, country_code, currency_code, merchant_account_ref, state)
  VALUES (p_driver, p_tenant, p_country, p_currency, p_merchant, 'in_progress')
  ON CONFLICT (driver_id, tenant_id, country_code, currency_code, merchant_account_ref) DO UPDATE
    SET state = 'in_progress', setup_token = gen_random_uuid(), submission_attempted_at = NULL, updated_at = now()
    WHERE public.driver_payment_accounts.state IN ('not_started','action_required')
       OR (public.driver_payment_accounts.state = 'in_progress'
           AND public.driver_payment_accounts.submission_attempted_at IS NULL
           AND public.driver_payment_accounts.updated_at < now() - interval '5 minutes')
  RETURNING *;
END $$;

REVOKE ALL ON FUNCTION public.claim_driver_payment_setup(uuid,uuid,text,text,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_driver_payment_setup(uuid,uuid,text,text,text) TO service_role;

-- Install the approved scope DISABLED. Activation is a separate reviewed step.
INSERT INTO public.driver_payout_markets(
  country_code, currency_code, provider, merchant_account_ref,
  enabled, merchant_approved, adapter_ready,
  capability_verified_at, capability_evidence_ref, merchant_mode,
  sandbox_driver_id, sandbox_tenant_id)
VALUES ('NG','NGN','flutterwave', current_setting('vaydu.merchant'),
  false, false, false, NULL, current_setting('vaydu.evidence'), 'test',
  current_setting('vaydu.driver')::uuid, current_setting('vaydu.tenant')::uuid);

COMMIT;
