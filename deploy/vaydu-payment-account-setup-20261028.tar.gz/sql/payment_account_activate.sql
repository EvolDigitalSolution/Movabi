-- =============================================================================
-- Activate ONLY the already-installed approved NG/NGN scope.
-- Separate from installation. Requires recorded capability evidence; never
-- auto-approves it. Transfers and all money-movement gates stay off.
-- =============================================================================
BEGIN;

SELECT set_config('vaydu.driver', :'driver', true);
SELECT set_config('vaydu.tenant', :'tenant', true);
SELECT set_config('vaydu.merchant', :'merchant', true);

DO $activate$
DECLARE
  v_driver text := current_setting('vaydu.driver');
  v_tenant text := current_setting('vaydu.tenant');
  v_merchant text := current_setting('vaydu.merchant');
  n integer;
BEGIN
  IF current_database() <> 'movabi_develop' THEN
    RAISE EXCEPTION 'Develop database required';
  END IF;
  IF to_regclass('public.driver_payout_markets') IS NULL
     OR to_regprocedure('public.claim_driver_payment_setup(uuid,uuid,text,text,text)') IS NULL THEN
    RAISE EXCEPTION 'Payment-account setup schema is not installed';
  END IF;

  UPDATE public.driver_payout_markets
     SET enabled = true, merchant_approved = true, adapter_ready = true,
         capability_verified_at = clock_timestamp()
   WHERE country_code = 'NG' AND currency_code = 'NGN' AND provider = 'flutterwave'
     AND merchant_account_ref = v_merchant
     AND sandbox_driver_id = v_driver::uuid
     AND sandbox_tenant_id = v_tenant::uuid
     AND capability_evidence_ref IS NOT NULL
     AND capability_evidence_ref <> '';
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n <> 1 THEN
    RAISE EXCEPTION 'Exactly one installed, evidenced approved scope row is required';
  END IF;

  IF (SELECT count(*) FROM public.driver_payout_markets WHERE enabled) <> 1 THEN
    RAISE EXCEPTION 'Only the single approved scope may be enabled';
  END IF;
END
$activate$;

COMMIT;
