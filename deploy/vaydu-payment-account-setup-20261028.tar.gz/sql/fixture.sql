-- Local disposable rehearsal fixture (never applied to a real database).
-- Mirrors the Supabase roles the canonical SQL references.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN CREATE ROLE anon NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN CREATE ROLE authenticated NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='service_role') THEN CREATE ROLE service_role NOLOGIN; END IF;
END $$;
CREATE TABLE IF NOT EXISTS public.profiles(
  id uuid PRIMARY KEY,
  tenant_id uuid,
  role text,
  registration_activated_at timestamptz,
  registration_country_code text,
  country_code text
);
CREATE TABLE IF NOT EXISTS public.market_availability(country_code text, supported_currency text);
INSERT INTO public.profiles VALUES
  ('318e6be9-9164-41fa-bb0c-c5ccd3526585','d0e8e8e8-e8e8-e8e8-e8e8-d0e8e8e8e8e8','driver',now(),'NG','NG')
ON CONFLICT DO NOTHING;
INSERT INTO public.market_availability VALUES ('NG','NGN');
