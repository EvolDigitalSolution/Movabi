﻿// Guarded mount: inject the baseline's supabaseAdmin, then expose the setup-only router.
module.exports = function mount(app, deps) {
  const db = deps && deps.db;
  if (!db || !db.auth || typeof db.auth.getUser !== 'function') throw new Error('supabase_admin_required');
  global.__VAYDU_SUPABASE_ADMIN__ = db;
  const mod = require('./router.js');
  const factory = mod.driverPaymentAccountRouter || (mod.default && mod.default.driverPaymentAccountRouter);
  if (typeof factory !== 'function') throw new Error('payment_account_router_missing');
  app.use('/api/driver-payment-account', factory(db));
};
