﻿module.exports = { supabaseAdmin: global.__VAYDU_SUPABASE_ADMIN__ };
