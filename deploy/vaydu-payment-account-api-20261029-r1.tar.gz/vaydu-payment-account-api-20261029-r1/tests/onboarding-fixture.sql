-- Synthetic integration schema only, never installed into develop.
ALTER TABLE public.profiles
 ADD full_name text DEFAULT 'Fixture Driver', ADD phone text DEFAULT '+2348000000000',
 ADD date_of_birth date DEFAULT '1990-01-01', ADD current_address text DEFAULT 'Fixture address',
 ADD driver_service_types text[] DEFAULT ARRAY['delivery'],
 ADD accepted_driver_agreement_at timestamptz DEFAULT now(),
 ADD verification_items jsonb DEFAULT '[{"key":"delivery_equipment_confirmed","value":"true"}]',
 ADD verification_status text DEFAULT 'not_started',ADD updated_at timestamptz DEFAULT now(),
 ADD market_city text,ADD city text,ADD zone_id uuid,ADD pricing_plan text,ADD subscription_status text,
 ADD driver_license_url text,ADD insurance_url text,ADD right_to_work_url text,
 ADD private_hire_vehicle_license_url text,ADD private_hire_insurance_url text,ADD goods_in_transit_insurance_url text,
 ADD driver_review_status text,ADD verification_notes text,ADD driver_review_notes text,
 ADD verification_blockers jsonb,ADD driver_review_blockers jsonb,ADD is_verified boolean DEFAULT false;
CREATE TABLE public.vehicles(id uuid DEFAULT gen_random_uuid(),user_id uuid,type text,make text,model text,color text,
 year integer,license_plate text,capacity text,service_eligibility text[],status text,created_at timestamptz DEFAULT now());
INSERT INTO public.vehicles(user_id,type,capacity,service_eligibility,status)
 VALUES('318e6be9-9164-41fa-bb0c-c5ccd3526585','bicycle','bicycle',ARRAY['delivery'],'active');
CREATE TABLE public.driver_onboarding_requests(id uuid DEFAULT gen_random_uuid(),driver_id uuid,requirement_code text,
 request_type text,item text,public_message text,status text,sent_at timestamptz,resolved_at timestamptz,
 updated_at timestamptz,permission_consumed_at timestamptz,created_at timestamptz DEFAULT now());
CREATE TABLE public.notifications(id uuid DEFAULT gen_random_uuid(),user_id uuid,title text,body text,created_at timestamptz,data jsonb);
CREATE TABLE public.driver_requirement_audit(id uuid DEFAULT gen_random_uuid(),driver_id uuid,event_type text,
 selected_services text[],requirement_codes text[],metadata jsonb);
CREATE FUNCTION public.gb_driver_mot_blocked(p_driver uuid) RETURNS boolean LANGUAGE sql AS 'SELECT false';
GRANT SELECT,UPDATE ON profiles,vehicles,driver_onboarding_requests TO service_role;
GRANT SELECT ON notifications TO service_role;
GRANT INSERT ON driver_requirement_audit TO service_role;
-- Disposable test control only; this file is never a release migration.
CREATE FUNCTION public.fixture_control(statement text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE result text;BEGIN
 IF ltrim(statement) ~* '^SELECT\s' THEN EXECUTE statement INTO result;RETURN coalesce(result,'');
 ELSE EXECUTE statement;RETURN '';END IF;
END $$;
REVOKE ALL ON FUNCTION public.fixture_control(text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.fixture_control(text) TO service_role;
