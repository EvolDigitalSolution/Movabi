-- DISPOSABLE RESTORE ONLY. All mutations are rolled back; no provider contact.
BEGIN;
DO $$
DECLARE first_claim public.driver_payment_accounts%ROWTYPE;
        second_claim public.driver_payment_accounts%ROWTYPE;
BEGIN
 IF current_setting('data_directory')<>'/tmp/vaydu-restore' OR current_database()<>'movabi_develop' THEN
  RAISE EXCEPTION 'Disposable rehearsal data directory required';
 END IF;
 IF has_table_privilege('authenticated','public.driver_payment_accounts','SELECT')
 OR has_table_privilege('anon','public.driver_payment_accounts','SELECT')
 OR has_function_privilege('service_role','public.bind_driver_payment_recovery(uuid,text,text)','EXECUTE')
 OR NOT has_function_privilege('service_role','public.fence_driver_payment_setup(uuid,uuid,text,text,text)','EXECUTE') THEN
  RAISE EXCEPTION 'Private setup privilege boundary failed';
 END IF;
 IF EXISTS(SELECT 1 FROM public.driver_payment_accounts
 WHERE driver_id='318e6be9-9164-41fa-bb0c-c5ccd3526585') THEN
  RAISE EXCEPTION 'Existing setup history requires reviewed reconciliation; clone test will not erase it';
 END IF;
 IF EXISTS(SELECT 1 FROM public.driver_payout_markets WHERE enabled) THEN RAISE EXCEPTION 'Installation must remain disabled';END IF;
 UPDATE public.driver_payout_markets SET enabled=true,merchant_approved=true,adapter_ready=true,
 capability_verified_at=now(),capability_evidence_ref='disposable-schema-assertion-only'
 WHERE country_code='NG' AND currency_code='NGN'
 AND sandbox_driver_id='318e6be9-9164-41fa-bb0c-c5ccd3526585'
 AND sandbox_tenant_id='d0e8e8e8-e8e8-e8e8-e8e8-d0e8e8e8e8e8';
 SELECT * INTO first_claim FROM public.claim_driver_payment_setup(
 '318e6be9-9164-41fa-bb0c-c5ccd3526585','d0e8e8e8-e8e8-e8e8-e8e8-d0e8e8e8e8e8','NG','NGN',
 (SELECT merchant_account_ref FROM public.driver_payout_markets WHERE country_code='NG' AND currency_code='NGN'));
 IF NOT FOUND THEN RAISE EXCEPTION 'First claim failed';END IF;
 UPDATE public.driver_payment_accounts SET updated_at=now()-interval '6 minutes' WHERE id=first_claim.id;
 SELECT * INTO second_claim FROM public.claim_driver_payment_setup(first_claim.driver_id,first_claim.tenant_id,'NG','NGN',first_claim.merchant_account_ref);
 IF NOT FOUND OR second_claim.setup_token=first_claim.setup_token THEN RAISE EXCEPTION 'Unsubmitted lease was not fenced';END IF;
 IF public.fence_driver_payment_setup(first_claim.id,first_claim.setup_token,'044','6789',repeat('a',64)) THEN RAISE EXCEPTION 'Stale worker accepted';END IF;
 IF NOT public.fence_driver_payment_setup(second_claim.id,second_claim.setup_token,'044','6789',repeat('a',64)) THEN RAISE EXCEPTION 'Current worker fence failed';END IF;
 UPDATE public.driver_payment_accounts SET updated_at=now()-interval '1 day' WHERE id=second_claim.id;
 IF EXISTS(SELECT 1 FROM public.claim_driver_payment_setup(second_claim.driver_id,second_claim.tenant_id,'NG','NGN',second_claim.merchant_account_ref)) THEN
  RAISE EXCEPTION 'Submitted intent was automatically reclaimed';
 END IF;
 UPDATE public.driver_payment_accounts SET state='reconciliation_required' WHERE id=second_claim.id;
 IF EXISTS(SELECT 1 FROM public.claim_driver_payment_setup(second_claim.driver_id,second_claim.tenant_id,'NG','NGN',second_claim.merchant_account_ref)) THEN
  RAISE EXCEPTION 'Uncertain outcome was automatically reclaimed';
 END IF;
 IF NOT public.bind_driver_payment_recovery(second_claim.id,'123','disposable-fixture-evidence-only') THEN RAISE EXCEPTION 'Manual candidate binding failed';END IF;
 IF (SELECT state FROM public.driver_payment_accounts WHERE id=second_claim.id)<>'reconciliation_required' THEN
  RAISE EXCEPTION 'Manual binding must not complete verification';
 END IF;
 -- Simulated verified candidate, only in this rolled-back disposable fixture.
 UPDATE public.driver_payment_accounts SET state='completed' WHERE id=second_claim.id;
 IF EXISTS(SELECT 1 FROM public.claim_driver_payment_setup(second_claim.driver_id,second_claim.tenant_id,'NG','NGN',second_claim.merchant_account_ref)) THEN
  RAISE EXCEPTION 'Completed setup was reclaimed';
 END IF;
END $$;
ROLLBACK;
