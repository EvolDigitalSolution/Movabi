-- Additive lineage: payment_account_setup_canonical.sql -> recovery-v2.
-- Never clears submission intent and never authorizes a second creation POST.
BEGIN;
DO $$ BEGIN
 IF current_database()<>'movabi_develop' OR to_regclass('public.driver_payment_accounts') IS NULL
 OR to_regprocedure('public.claim_driver_payment_setup(uuid,uuid,text,text,text)') IS NULL THEN
  RAISE EXCEPTION 'Complete canonical setup-v1 required';
 END IF;
 IF to_regprocedure('public.fence_driver_payment_setup(uuid,uuid,text,text,text)') IS NOT NULL
 OR to_regprocedure('public.bind_driver_payment_recovery(uuid,text,text)') IS NOT NULL THEN
  RAISE EXCEPTION 'Recovery-v2 already present or partially installed; reconcile first';
 END IF;
END $$;

ALTER TABLE public.driver_payment_accounts ADD COLUMN recovery_evidence_ref text;

CREATE FUNCTION public.fence_driver_payment_setup(p_id uuid,p_token uuid,p_bank text,p_last4 text,p_fingerprint text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
BEGIN
 IF p_bank !~ '^\d{3,6}$' OR p_last4 !~ '^\d{4}$' OR p_fingerprint !~ '^[a-f0-9]{64}$' THEN RETURN false;END IF;
 UPDATE public.driver_payment_accounts a SET submission_attempted_at=now(),bank_code=p_bank,last4=p_last4,fingerprint=p_fingerprint,updated_at=now()
 WHERE a.id=p_id AND a.setup_token=p_token AND a.state='in_progress' AND a.submission_attempted_at IS NULL
 AND EXISTS(SELECT 1 FROM public.driver_payout_markets m JOIN public.profiles p ON p.id=a.driver_id
 WHERE m.country_code=a.country_code AND m.currency_code=a.currency_code AND m.provider='flutterwave'
 AND m.enabled AND m.merchant_approved AND m.adapter_ready AND m.merchant_mode='test'
 AND m.capability_verified_at IS NOT NULL AND m.capability_evidence_ref IS NOT NULL
 AND m.merchant_account_ref=a.merchant_account_ref AND m.sandbox_driver_id=a.driver_id AND m.sandbox_tenant_id=a.tenant_id
 AND a.driver_id='318e6be9-9164-41fa-bb0c-c5ccd3526585' AND a.tenant_id='d0e8e8e8-e8e8-e8e8-e8e8-d0e8e8e8e8e8'
 AND p.role='driver' AND p.tenant_id=a.tenant_id AND p.registration_activated_at IS NOT NULL
 AND coalesce(p.registration_country_code,p.country_code)='NG' AND a.country_code='NG' AND a.currency_code='NGN');
 RETURN FOUND;
END $$;
REVOKE ALL ON FUNCTION public.fence_driver_payment_setup(uuid,uuid,text,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.fence_driver_payment_setup(uuid,uuid,text,text,text) TO service_role;

CREATE FUNCTION public.freeze_driver_payment_submission() RETURNS trigger LANGUAGE plpgsql SET search_path=public,pg_temp AS $$
BEGIN
 IF OLD.submission_attempted_at IS NOT NULL AND
 (NEW.submission_attempted_at,NEW.setup_token,NEW.bank_code,NEW.last4,NEW.fingerprint) IS DISTINCT FROM
 (OLD.submission_attempted_at,OLD.setup_token,OLD.bank_code,OLD.last4,OLD.fingerprint) THEN
  RAISE EXCEPTION 'Submitted setup terms are immutable; reconciliation only';
 END IF;
 IF OLD.beneficiary_id IS NOT NULL AND NEW.beneficiary_id IS DISTINCT FROM OLD.beneficiary_id THEN
  RAISE EXCEPTION 'Candidate identity is immutable';
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER freeze_driver_payment_submission BEFORE UPDATE ON public.driver_payment_accounts
FOR EACH ROW EXECUTE FUNCTION public.freeze_driver_payment_submission();
REVOKE ALL ON FUNCTION public.freeze_driver_payment_submission() FROM PUBLIC,anon,authenticated,service_role;

-- Manual support recovery: operator reviews the merchant's beneficiary creation
-- evidence and binds ONLY its identifier. The user route must then GET and verify
-- that candidate against the frozen HMAC. This function cannot complete setup.
CREATE FUNCTION public.bind_driver_payment_recovery(p_id uuid,p_candidate text,p_evidence text)
RETURNS boolean LANGUAGE plpgsql SET search_path=public,pg_temp AS $$
BEGIN
 IF p_candidate !~ '^[1-9][0-9]*$' OR length(btrim(p_evidence))<8 THEN RAISE EXCEPTION 'Reviewed candidate evidence required';END IF;
 UPDATE public.driver_payment_accounts SET beneficiary_id=p_candidate,recovery_evidence_ref=p_evidence,state='reconciliation_required',updated_at=now()
 WHERE id=p_id AND submission_attempted_at IS NOT NULL AND beneficiary_id IS NULL
 AND state IN('in_progress','reconciliation_required')
 AND driver_id='318e6be9-9164-41fa-bb0c-c5ccd3526585' AND tenant_id='d0e8e8e8-e8e8-e8e8-e8e8-d0e8e8e8e8e8'
 AND country_code='NG' AND currency_code='NGN';
 RETURN FOUND;
END $$;
REVOKE ALL ON FUNCTION public.bind_driver_payment_recovery(uuid,text,text) FROM PUBLIC,anon,authenticated,service_role;
COMMIT;
